# Campus Library — CS543 GraphQL Assignment

A small end-to-end web application built with HTML/CSS, Node.js, Apollo Server, GraphQL, and MySQL.

## Requirements

- Node.js 18 or newer
- MySQL Community Server 8.x (or compatible)
- VS Code and the Live Server extension

## Project structure

```text
campus-library/
├── schema.sql
├── db.js
├── server.js
├── package.json
├── .env.example
├── .gitignore
├── README.md
└── public/
    ├── index.html
    └── style.css
```

## Setup on Windows

1. Install Node.js and MySQL Server if they are not already installed.
2. Open this folder in VS Code.
3. Open a terminal in the project folder.
4. Log into MySQL and run the SQL file (details in the setup instructions supplied separately):
   ```bash
   mysql -u root -p
   ```
   At the `mysql>` prompt, run `SOURCE C:/full/path/to/campus-library/schema.sql;` using the actual path on your computer.
5. Copy `.env.example` to `.env` and set `DB_PASSWORD` to your MySQL password. Do not share or commit `.env`.
6. Install Node dependencies:
   ```bash
   npm install
   ```
7. Start the API:
   ```bash
   npm start
   ```
8. Open `http://localhost:4000/` to use Apollo Sandbox. The terminal should show that the API is ready.
9. In VS Code, right-click `public/index.html` and select **Open with Live Server**. The page usually opens at `http://127.0.0.1:5500/public/` or a similar local address.
10. Add a book through the form, then verify it is saved in MySQL:
    ```sql
    USE gqldemo;
    SELECT title, year, author_id FROM books ORDER BY id;
    ```

## GraphQL query to demonstrate

```graphql
query {
  authors {
    id
    name
    country
    books {
      title
      year
    }
  }
}
```

## GraphQL mutation to demonstrate

```graphql
mutation {
  addBook(title: "GraphQL for Beginners", year: 2025, authorId: "2") {
    id
    title
    year
    author {
      name
    }
  }
}
```

If author ID `2` does not exist in your database, use an ID returned by the query.

## Troubleshooting

- **Access denied for MySQL:** verify `DB_USER` and `DB_PASSWORD` in `.env`.
- **Unknown database `gqldemo`:** run `schema.sql` in MySQL first.
- **`Cannot find module`:** run `npm install` from the project folder.
- **Port 4000 is in use:** stop the other process or set a different `PORT` in `.env`, then update `API` in `public/index.html`.
- **Page remains on loading/error:** make sure `node server.js` is still running and visit `http://localhost:4000/` to verify the API.
- **CORS errors:** open the page through Live Server rather than by double-clicking the HTML file.

## What to demonstrate

1. Show the `authors` and `books` tables in MySQL.
2. Run the nested authors/books query in Apollo Sandbox.
3. Open the Campus Library frontend and show the existing records.
4. Add a book using the form.
5. Run the SQL verification query to show that the new row persisted.

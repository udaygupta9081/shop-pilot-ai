# ShopPilot AI — CS543 Assignment 5

## Requirements
- Node.js 18+
- curl (for reproducing `curl-transcript.txt`)
- No external npm dependencies

## Start
```bash
npm start
```
The API starts at `http://localhost:3000`.

## Test
In another terminal:
```bash
npm test
```

## Demo request
```bash
curl -i http://localhost:3000/products?category=Beauty
curl -i http://localhost:3000/products/101
curl -i -X POST http://localhost:3000/products \
  -H 'Authorization: Bearer shoppilot-demo-token' \
  -H 'Idempotency-Key: create-demo-001' \
  -H 'Content-Type: application/json' \
  -d '{"name":"Demo Product","category":"Accessories","price":250,"stock":10}'
```

## Important submission edits
Before submitting, replace the Team ID placeholder in `NOTES.md` and add every team member's roll number and name. The Assignment 5 brief explicitly requires these. Check the CampusEats method map against your actual Assignment 4 endpoint list if your team has additional routes.

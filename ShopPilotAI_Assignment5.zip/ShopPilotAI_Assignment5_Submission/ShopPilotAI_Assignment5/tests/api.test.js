'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const http = require('node:http');
let child, base;
function request(method, path, headers = {}, body) {
  return new Promise((resolve, reject) => {
    const data = body === undefined ? undefined : JSON.stringify(body);
    const req = http.request(base + path, { method, headers: { Accept: 'application/json', ...(data ? { 'Content-Type': 'application/json' } : {}), ...headers } }, res => {
      let raw = ''; res.on('data', c => raw += c); res.on('end', () => { let json; try { json = raw ? JSON.parse(raw) : undefined; } catch {} resolve({ status: res.statusCode, headers: res.headers, body: json, raw }); });
    }); req.on('error', reject); if (data) req.write(data); req.end();
  });
}
test.before(async () => {
  const port = 34000 + Math.floor(Math.random() * 1000); base = `http://127.0.0.1:${port}`;
  child = spawn(process.execPath, ['server.js'], { cwd: require('node:path').join(__dirname, '..'), env: { ...process.env, PORT: String(port), RATE_LIMIT: '1000' }, stdio: 'ignore' });
  for (let i = 0; i < 50; i++) { try { await request('GET', '/health'); break; } catch { await new Promise(r => setTimeout(r, 50)); } }
});
test.after(() => { if (child) child.kill(); });
test('health and filtered list are readable', async () => {
  assert.equal((await request('GET', '/health')).status, 200);
  const r = await request('GET', '/products?category=Beauty&sort=price&limit=5&offset=0');
  assert.equal(r.status, 200); assert.equal(r.body.items.length, 1); assert.match(r.headers['cache-control'], /public/);
});
test('conditional GET returns 304 with no body', async () => {
  const first = await request('GET', '/products/101'); assert.equal(first.status, 200);
  const second = await request('GET', '/products/101', { 'If-None-Match': first.headers.etag });
  assert.equal(second.status, 304); assert.equal(second.raw, '');
});
test('stale conditional write returns 412', async () => {
  const r = await request('PUT', '/products/101', { Authorization: 'Bearer demo', 'If-Match': '"old-tag"' }, { name: 'Changed', category: 'Beauty', price: 1, stock: 1 });
  assert.equal(r.status, 412);
});
test('idempotency key replays original create', async () => {
  const key = 'test-create-once'; const body = { name: 'Test Widget Unique', category: 'Accessories', price: 100, stock: 3 };
  const a = await request('POST', '/products', { Authorization: 'Bearer demo', 'Idempotency-Key': key }, body);
  const b = await request('POST', '/products', { Authorization: 'Bearer demo', 'Idempotency-Key': key }, body);
  assert.equal(a.status, 201); assert.equal(b.status, 201); assert.equal(a.body.id, b.body.id); assert.equal(b.headers['idempotency-replayed'], 'true');
});
test('malformed JSON is 400; domain validation is 422; missing route is 404; missing auth is 401', async () => {
  const badJson = await new Promise((resolve, reject) => { const req = http.request(base + '/products', { method: 'POST', headers: { Authorization: 'Bearer demo', 'Idempotency-Key': 'malformed', 'Content-Type': 'application/json', Accept: 'application/json' } }, res => { let raw=''; res.on('data', c=>raw+=c); res.on('end',()=>resolve({status:res.statusCode,raw})); }); req.on('error',reject); req.write('{oops'); req.end(); });
  assert.equal(badJson.status, 400);
  assert.equal((await request('POST', '/products', { Authorization: 'Bearer demo', 'Idempotency-Key': 'invalid-domain' }, { name: '', category: 'x', price: 1, stock: 1 })).status, 422);
  assert.equal((await request('GET', '/products/does-not-exist')).status, 404);
  assert.equal((await request('POST', '/products', { 'Idempotency-Key': 'no-auth' }, { name: 'X', category: 'Y', price: 1, stock: 1 })).status, 401);
});
test('OPTIONS returns Allow and CORS headers', async () => {
  const r = await request('OPTIONS', '/products'); assert.equal(r.status, 204); assert.match(r.headers.allow, /GET/); assert.ok(r.headers['access-control-allow-origin']);
});

'use strict';
const http = require('node:http');
const zlib = require('node:zlib');
const crypto = require('node:crypto');
const { URL } = require('node:url');

const PORT = Number(process.env.PORT || 3000);
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || 'http://localhost:5173';
const TOKEN = process.env.DEMO_TOKEN || 'shoppilot-demo-token';
const RATE_LIMIT = Number(process.env.RATE_LIMIT || 100);
const RATE_WINDOW_MS = 60_000;
const products = new Map([
  ['101', { id: '101', name: 'Everyday Sunscreen SPF 50', category: 'Beauty', price: 599, currency: 'INR', stock: 25, version: 1 }],
  ['102', { id: '102', name: 'Noise-Cancelling Headphones', category: 'Electronics', price: 4999, currency: 'INR', stock: 12, version: 1 }]
]);
const idempotency = new Map();
const budgets = new Map();
let nextId = 103;

function send(res, status, data, headers = {}) {
  const body = data === undefined || status === 204 || status === 304 ? '' : JSON.stringify(data);
  const h = { 'X-Content-Type-Options': 'nosniff', 'Strict-Transport-Security': 'max-age=31536000; includeSubDomains', 'Access-Control-Allow-Origin': ALLOWED_ORIGIN, 'Vary': 'Origin, Accept-Encoding', ...headers };
  if (body) h['Content-Type'] = 'application/json; charset=utf-8';
  if (body && Buffer.byteLength(body) > 512 && /gzip/.test(res.req.headers['accept-encoding'] || '')) {
    h['Content-Encoding'] = 'gzip'; res.writeHead(status, h); return res.end(zlib.gzipSync(body));
  }
  res.writeHead(status, h); res.end(body);
}
function error(res, status, code, message, headers = {}) { send(res, status, { error: { code, message } }, headers); }
function etag(p) { return `"product-${p.id}-v${p.version}"`; }
function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = ''; req.on('data', chunk => { raw += chunk; if (raw.length > 1_000_000) { reject(Object.assign(new Error('Request body too large'), { status: 400 })); req.destroy(); } });
    req.on('end', () => { if (!raw) return resolve({}); try { resolve(JSON.parse(raw)); } catch { reject(Object.assign(new Error('Malformed JSON body'), { status: 400 })); } });
    req.on('error', reject);
  });
}
function rateLimit(req, res) {
  const key = req.socket.remoteAddress || 'unknown'; const now = Date.now();
  let b = budgets.get(key); if (!b || now >= b.resetAt) b = { count: 0, resetAt: now + RATE_WINDOW_MS };
  b.count++; budgets.set(key, b);
  const remaining = Math.max(0, RATE_LIMIT - b.count);
  res.setHeader('X-RateLimit-Limit', String(RATE_LIMIT)); res.setHeader('X-RateLimit-Remaining', String(remaining));
  if (b.count > RATE_LIMIT) { error(res, 429, 'RATE_LIMIT_EXCEEDED', 'Request budget exceeded; retry later.', { 'Retry-After': String(Math.max(1, Math.ceil((b.resetAt - now) / 1000))) }); return false; }
  return true;
}
function authorized(req) { return /^Bearer\s+\S+$/i.test(req.headers.authorization || ''); }
function acceptJson(req, res) {
  const accept = req.headers.accept || '*/*';
  if (!(accept.includes('*/*') || accept.includes('application/json'))) { error(res, 406, 'NOT_ACCEPTABLE', 'This API only produces application/json.'); return false; }
  return true;
}
function allowOverride(req) {
  const override = (req.headers['x-http-method-override'] || '').toUpperCase();
  return ['PUT', 'PATCH', 'DELETE'].includes(override) ? override : req.method;
}

const server = http.createServer(async (req, res) => {
  req.res = res;
  if (!rateLimit(req, res)) return;
  if (req.method === 'OPTIONS') {
    return send(res, 204, undefined, {
      'Allow': 'GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS',
      'Access-Control-Allow-Methods': 'GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Authorization, Content-Type, Accept, If-Match, If-None-Match, Idempotency-Key, X-HTTP-Method-Override',
      'Access-Control-Max-Age': '600'
    });
  }
  if (!acceptJson(req, res)) return;
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const method = allowOverride(req);
  const parts = url.pathname.split('/').filter(Boolean);
  try {
    // Public read endpoints: never mutate state.
    if (url.pathname === '/health' && method === 'GET') return send(res, 200, { status: 'ok', service: 'ShopPilot AI Product API' }, { 'Cache-Control': 'no-store' });
    if (url.pathname === '/products' && method === 'GET') {
      let list = [...products.values()].map(({ version, ...p }) => p);
      const category = url.searchParams.get('category'); const q = url.searchParams.get('q');
      const sort = url.searchParams.get('sort') || 'name'; const order = url.searchParams.get('order') === 'desc' ? -1 : 1;
      if (category) list = list.filter(p => p.category.toLowerCase() === category.toLowerCase());
      if (q) list = list.filter(p => `${p.name} ${p.category}`.toLowerCase().includes(q.toLowerCase()));
      if (!['name', 'price'].includes(sort)) return error(res, 400, 'INVALID_SORT', 'sort must be name or price.');
      list.sort((a, b) => (a[sort] < b[sort] ? -1 : a[sort] > b[sort] ? 1 : 0) * order);
      const limit = Math.min(100, Math.max(1, Number(url.searchParams.get('limit') || 20)));
      const offset = Math.max(0, Number(url.searchParams.get('offset') || 0));
      if (!Number.isFinite(limit) || !Number.isFinite(offset)) return error(res, 400, 'INVALID_PAGINATION', 'limit and offset must be numbers.');
      const total = list.length; list = list.slice(offset, offset + limit);
      return send(res, 200, { items: list, total, limit, offset }, { 'Cache-Control': 'public, max-age=30' });
    }
    if (parts[0] === 'products' && parts.length === 2) {
      const id = parts[1]; const p = products.get(id);
      if (method === 'GET' || method === 'HEAD') {
        if (!p) return error(res, 404, 'PRODUCT_NOT_FOUND', `Product ${id} was not found.`);
        const tag = etag(p); res.setHeader('ETag', tag); res.setHeader('Cache-Control', 'private, max-age=60, must-revalidate');
        if (req.headers['if-none-match'] === tag || req.headers['if-none-match'] === '*') return send(res, 304, undefined, { ETag: tag, 'Cache-Control': 'private, max-age=60, must-revalidate' });
        const { version, ...publicProduct } = p;
        return send(res, 200, method === 'HEAD' ? undefined : publicProduct, { ETag: tag, 'Cache-Control': 'private, max-age=60, must-revalidate' });
      }
      if (['PUT', 'PATCH', 'DELETE'].includes(method)) {
        if (!authorized(req)) return error(res, 401, 'UNAUTHORIZED', 'Provide Authorization: Bearer <token>.', { 'WWW-Authenticate': 'Bearer realm="ShopPilot AI"' });
        if (!p) return error(res, 404, 'PRODUCT_NOT_FOUND', `Product ${id} was not found.`);
        if (method === 'DELETE') {
          if (req.headers['if-match'] && req.headers['if-match'] !== etag(p) && req.headers['if-match'] !== '*') return error(res, 412, 'PRECONDITION_FAILED', 'Product changed; fetch the latest ETag before deleting.');
          products.delete(id); return send(res, 204, undefined, { 'Cache-Control': 'no-store' });
        }
        if (!req.headers['if-match']) return error(res, 428, 'PRECONDITION_REQUIRED', 'Send If-Match with the current ETag to prevent lost updates.');
        if (req.headers['if-match'] !== etag(p) && req.headers['if-match'] !== '*') return error(res, 412, 'PRECONDITION_FAILED', 'Product changed; fetch the latest ETag before updating.', { ETag: etag(p) });
        const body = await readBody(req);
        const merged = method === 'PUT' ? { id, currency: 'INR', ...body, id, version: p.version + 1 } : { ...p, ...body, id, version: p.version + 1 };
        if (typeof merged.name !== 'string' || !merged.name.trim() || typeof merged.category !== 'string' || !merged.category.trim() || !Number.isFinite(merged.price) || merged.price < 0 || !Number.isInteger(merged.stock) || merged.stock < 0) return error(res, 422, 'INVALID_PRODUCT', 'name and category are required; price must be non-negative; stock must be a non-negative integer.');
        products.set(id, merged); const { version, ...out } = merged;
        return send(res, 200, out, { ETag: etag(merged), 'Cache-Control': 'no-store' });
      }
    }
    if (url.pathname === '/products' && method === 'POST') {
      if (!authorized(req)) return error(res, 401, 'UNAUTHORIZED', 'Provide Authorization: Bearer <token>.', { 'WWW-Authenticate': 'Bearer realm="ShopPilot AI"' });
      const key = req.headers['idempotency-key'];
      if (!key || !String(key).trim()) return error(res, 400, 'IDEMPOTENCY_KEY_REQUIRED', 'POST /products requires an Idempotency-Key header.');
      if (idempotency.has(key)) { const prior = idempotency.get(key); return send(res, prior.status, prior.body, { Location: prior.location, 'Idempotency-Replayed': 'true', 'Cache-Control': 'no-store' }); }
      const body = await readBody(req);
      if (typeof body.name !== 'string' || !body.name.trim()) return error(res, 422, 'INVALID_PRODUCT', 'name must be a non-empty string.');
      if (typeof body.category !== 'string' || !body.category.trim() || !Number.isFinite(body.price) || body.price < 0 || !Number.isInteger(body.stock ?? 0) || (body.stock ?? 0) < 0) return error(res, 422, 'INVALID_PRODUCT', 'category is required; price must be non-negative; stock must be a non-negative integer.');
      if ([...products.values()].some(p => p.name.toLowerCase() === body.name.trim().toLowerCase())) return error(res, 409, 'PRODUCT_CONFLICT', 'A product with this name already exists.');
      const id = String(nextId++); const p = { id, name: body.name.trim(), category: body.category.trim(), price: body.price, currency: body.currency || 'INR', stock: body.stock ?? 0, version: 1 };
      products.set(id, p); const { version, ...out } = p; const location = `/products/${id}`;
      const record = { status: 201, body: out, location }; idempotency.set(key, record);
      return send(res, 201, out, { Location: location, ETag: etag(p), 'Cache-Control': 'no-store' });
    }
    if (url.pathname === '/products' && ['PUT', 'PATCH', 'DELETE'].includes(method)) return error(res, 405, 'METHOD_NOT_ALLOWED', 'Use the item resource for updates/deletes.', { Allow: 'GET, POST, OPTIONS' });
    if (url.pathname === '/products' || parts[0] === 'products') return error(res, 405, 'METHOD_NOT_ALLOWED', 'Method not allowed for this resource.', { Allow: 'GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS' });
    return error(res, 404, 'NOT_FOUND', 'Route was not found.');
  } catch (e) {
    if (!res.headersSent) error(res, e.status || 400, e.status === 400 ? 'BAD_REQUEST' : 'INTERNAL_ERROR', e.message || 'Request failed.');
  }
});
server.listen(PORT, () => console.log(`ShopPilot AI Product API listening on http://localhost:${PORT}`));
module.exports = { server, products, idempotency };

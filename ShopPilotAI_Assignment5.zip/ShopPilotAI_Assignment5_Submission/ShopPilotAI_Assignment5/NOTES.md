# CS543 Web Services — Assignment 5: HTTP Methods & Headers

**Project adaptation:** ShopPilot AI Product API, based on the uploaded ShopPilot AI Product Intelligence Platform blueprint. The blueprint identifies Product, Search & Discovery, Review, Price, Recommendation, RAG, and agent orchestration services. This submission implements a runnable Product API slice; product verdict/RAG agents are architectural context, not falsely represented as implemented here. Assignment 3's ZIP contains a SOAP/WSDL integration example for ShopPilot AI's SMS notification partner. That contract remains an integration artifact; Assignment 5's HTTP resource API is implemented separately.

**Team ID:** [FILL IN TEAM ID]

**Team members (Roll No — Name):**
- 20251651046 — Ritesh Jadhav
- [Add every other team member's roll number and full name]

## Run

Requires Node.js 18 or later; no npm dependencies are required.

```bash
cd ShopPilotAI_Assignment5
npm start
# or: node server.js
```

API listens at `http://localhost:3000`. Demo bearer-token header for protected writes: `Authorization: Bearer shoppilot-demo-token`. This is header-handling only, not a real authentication system. Set `PORT`, `ALLOWED_ORIGIN`, `DEMO_TOKEN`, and `RATE_LIMIT` environment variables if needed.

Run tests in another terminal:

```bash
npm test
```

## A1 — HTTP method map

The Assignment 5 brief requests the CampusEats map from Assignment 4. The uploaded Assignment 3 ZIP contains the MsgBridge SOAP SMS integration rather than the Assignment 4 REST endpoint list, so the following table records the known CampusEats Order contract from the existing project context and then maps the ShopPilot AI implementation. Verify any team-specific Assignment 4 routes before submission.

### CampusEats method map (course baseline)

| Action | Method + URL | Safe? | Idempotent? | Reason |
|---|---|---:|---:|---|
| Create an order | `POST /orders` | No | Not inherently | Creates a new order; use `Idempotency-Key` for safe retry. |
| Read one order | `GET /orders/{id}` | Yes | Yes | Reads one order without state changes. |
| List/filter orders | `GET /orders?status=CONFIRMED&limit=20&offset=0` | Yes | Yes | Query parameters filter and paginate a pure read. |
| Change order status | `PUT /orders/{id}/status` | No | Depends on request semantics; replacement of same status is effectively idempotent | Update is guarded by `If-Match` to prevent lost updates. |
| Cancel order | `POST /orders/{id}/cancellation` | No | Not inherently | Domain action is modeled as a sub-resource; use an idempotency key if retrying. |

### ShopPilot AI Product API (implemented)

| Action | Method + URL | Success | Safe? | Idempotent? |
|---|---|---:|---:|---:|
| Health check | `GET /health` | 200 | Yes | Yes |
| Search/list products | `GET /products?category=Beauty&sort=price&order=asc&limit=20&offset=0` | 200 | Yes | Yes |
| Read one product | `GET /products/{id}` | 200 (304 if unchanged) | Yes | Yes |
| Create product | `POST /products` | 201 + `Location` | No | With same `Idempotency-Key`, replay returns original result |
| Replace product | `PUT /products/{id}` | 200 | No | Repeating same replacement has same intended effect, but `If-Match` must match current version |
| Partially update product | `PATCH /products/{id}` | 200 | No | Depends on patch; guarded by `If-Match` |
| Delete product | `DELETE /products/{id}` | 204 | No | Deleting an already deleted item returns 404; guarded by optional `If-Match` |
| Discover supported methods | `OPTIONS /products` | 204 + `Allow` | Yes | Yes |

No GET route mutates state. Product-list filtering, sorting and pagination use query parameters, not action verbs in URLs.

## A2 — Non-CRUD actions

Actions such as checkout, cancel, or set-availability should be modeled as POST to a resource sub-path, e.g. `POST /orders/42/cancellation` or `POST /products/101/price-alerts`. Avoid verb-leaking paths such as `/cancelOrder`. ShopPilot's price-alert action, when implemented, should use `POST /products/{id}/price-alerts` because creating an alert is a domain action/resource creation.

## A3 — Safe and idempotent

Safe means the request does not change server state. Idempotent means repeated identical requests have the same intended effect. GET, HEAD and OPTIONS are safe and idempotent. PUT and DELETE are defined as idempotent methods, although this demo returns 404 for a repeated deletion of a now-missing resource. POST create is not inherently idempotent; the required `Idempotency-Key` stores the original response and replays it for a duplicate key. PATCH may or may not be idempotent depending on the patch operation. The risky operation is create: duplicate products/alerts/orders can create duplicate work or notifications, so the idempotency key is the retry guard.

## A4 — Query parameters

Example: `GET /products?category=Beauty&q=sunscreen&sort=price&order=asc&limit=10&offset=0`. This is a pure read. Invalid sort values return 400. POST search may be justified for a complex query that is too large/sensitive for a URL or requires a structured request body, but it sacrifices the ordinary GET semantics and convenient browser/proxy caching, bookmarking, and safe automatic retries.

## A5 — OPTIONS, Allow, and method override

`OPTIONS /products` returns `Allow: GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS`, plus CORS preflight headers. For clients that cannot send PUT/PATCH/DELETE, the server documents `X-HTTP-Method-Override: PUT|PATCH|DELETE` as a fallback on a POST request. The normal method should be preferred; override is not a security bypass and protected operations still require the bearer header.

## A6 — Full HTTP exchange

**Request** (HTTP/1.1):

```http
POST /products HTTP/1.1
Host: localhost:3000
Authorization: Bearer shoppilot-demo-token
Idempotency-Key: create-sunscreen-001
Content-Type: application/json
Accept: application/json

{"name":"Mineral Sunscreen SPF 50","category":"Beauty","price":799,"stock":18,"currency":"INR"}
```

**Response** (example; assigned ID may vary with server state):

```http
HTTP/1.1 201 Created
Content-Type: application/json; charset=utf-8
Location: /products/103
ETag: "product-103-v1"
Cache-Control: no-store
X-Content-Type-Options: nosniff
Access-Control-Allow-Origin: http://localhost:5173

{"id":"103","name":"Mineral Sunscreen SPF 50","category":"Beauty","price":799,"currency":"INR","stock":18}
```

The exact response headers include framework/runtime-generated `Date` and `Connection` fields where applicable. Production deployment must terminate HTTPS; HSTS is emitted by the demo server.

## B1–B7 / D2 — Headers table

| Endpoint | Request headers | Response headers / behavior |
|---|---|---|
| `GET /products` | `Accept: application/json` (or `*/*`) | `Content-Type: application/json`; `Cache-Control: public, max-age=30`; rate-limit headers; CORS and security headers |
| `GET /products/{id}` | `Accept`; optional `If-None-Match` | 200 with `ETag`, `Cache-Control: private, max-age=60, must-revalidate`; matching tag returns 304 with no body |
| `POST /products` | `Authorization: Bearer …`, `Idempotency-Key`, `Content-Type: application/json`, `Accept` | 201 + `Location`, `ETag`, JSON content type, `Cache-Control: no-store`; duplicate key replays original result with `Idempotency-Replayed: true` |
| `PUT/PATCH /products/{id}` | `Authorization: Bearer …`, current `If-Match`, JSON content type/body | 200 + new `ETag`; 412 on stale ETag; 428 if If-Match missing; 422 for domain validation |
| `DELETE /products/{id}` | `Authorization: Bearer …`; optional `If-Match` | 204, no body, `Cache-Control: no-store`; 412 for stale tag |
| Any protected write | `Authorization: Bearer <token>` | Missing/empty token returns 401 and `WWW-Authenticate: Bearer …` |
| Any request | `Accept` | Unsupported media type requested through Accept returns 406 |
| `OPTIONS /products` | Browser preflight may include `Origin`, `Access-Control-Request-Method`, `Access-Control-Request-Headers` | 204, `Allow`, `Access-Control-Allow-Origin`, methods/headers and max-age |
| Rate-limited request | Client identity derived from remote address | `X-RateLimit-Limit`, `X-RateLimit-Remaining`; over budget returns 429 + `Retry-After` |
| Error response | As relevant above | JSON error object, `Content-Type: application/json`, security/CORS headers |

`Content-Encoding: gzip` is added when a JSON response body is larger than 512 bytes and the client advertises gzip. `Date` is provided by Node's HTTP runtime; `Server` is intentionally not disclosed. `Strict-Transport-Security` is set for production HTTPS deployment; local development uses HTTP.

## B2 — Status codes

- `200 OK`: read or successful update.
- `201 Created`: successful creation; `Location` points to the created resource.
- `204 No Content`: successful delete or OPTIONS response, with no body.
- `304 Not Modified`: client's cached representation remains current; no body.
- `400 Bad Request`: malformed JSON, missing idempotency key, or invalid query syntax.
- `401 Unauthorized`: missing/empty bearer token on a protected write.
- `404 Not Found`: unknown route or product ID.
- `406 Not Acceptable`: client does not accept JSON.
- `409 Conflict`: duplicate product name.
- `412 Precondition Failed`: `If-Match` ETag is stale.
- `422 Unprocessable Entity`: syntactically valid JSON violates product-domain validation.
- `428 Precondition Required`: update omitted `If-Match`.
- `429 Too Many Requests`: per-client budget exceeded; includes `Retry-After`.
- `405 Method Not Allowed`: unsupported method for resource; includes `Allow` where defined.

## C1–C3 — Conditional requests and idempotency

An example tag is `ETag: "product-101-v1"`. A `GET /products/101` with `If-None-Match: "product-101-v1"` returns `304 Not Modified` with an empty body, avoiding a redundant representation transfer. A write with `If-Match: "product-101-v0"` returns `412 Precondition Failed` and does not overwrite the newer version. After a successful update, the tag increments, e.g. `"product-101-v2"`.

The same `Idempotency-Key` on `POST /products` replays the stored original 201 response and resource location. This prevents duplicate products when the client times out after the server committed the first create. In a full production system, idempotency records should be durable, scoped to the authenticated client, have a retention policy, and reject reuse of a key with a different request fingerprint.

## C4 — Safe retry plan

| Risky endpoint | Retry mechanism | Why |
|---|---|---|
| `POST /products` (create) | `Idempotency-Key` | POST can create duplicates if response is lost and client retries. |
| `GET /products/{id}` | `If-None-Match` | Saves bandwidth and reuses cached product data when unchanged; GET itself is already safe. |
| `PUT/PATCH /products/{id}` | `If-Match` | Detects stale client state and prevents lost updates; a mismatch returns 412. |
| `DELETE /products/{id}` | Optional `If-Match` | Avoids deleting a newer version than the one the client reviewed. |
| `POST /orders/{id}/cancellation` or price-alert creation (design) | `Idempotency-Key` | Prevents duplicate cancellation processing or duplicate alert/notification creation. |

## D1 — curl -v transcript

See `curl-transcript.txt`. It is generated by running the included server and executing curl with verbose output. It demonstrates create + Location, idempotent replay, conditional GET 304, stale write 412, malformed JSON 400, missing product 404 and missing authorization 401.

## D3 — Eight written answers

### 1. Three endpoints: method, success status, most important response header

- `POST /products` → **201 Created**; `Location` identifies the new resource so the client can immediately retrieve it.
- `GET /products/{id}` → **200 OK**; `ETag` identifies the version and enables conditional GET/write checks.
- `DELETE /products/{id}` → **204 No Content**; no representation is returned because deletion succeeded and there is no response body.

### 2. Which endpoints are safe/idempotent? Which is neither, and how is it retry-safe?

GET/HEAD/OPTIONS are safe and idempotent. PUT and DELETE are idempotent in intended effect; they are not safe because they modify state. POST create is neither safe nor inherently idempotent. It is made retry-safe by recording the first result against `Idempotency-Key` and replaying that result on repeat requests.

### 3. ETag, 304 request, 412 write, and purpose

A product can return `ETag: "product-101-v1"`. `GET /products/101` with `If-None-Match: "product-101-v1"` returns 304 and no body, saving bandwidth. `PUT /products/101` with a stale `If-Match: "product-101-v0"` returns 412, preventing one editor from overwriting a newer version.

### 4. Exact requests for 422 and 400

422 (valid JSON, invalid domain value):

```http
POST /products HTTP/1.1
Host: localhost:3000
Authorization: Bearer shoppilot-demo-token
Idempotency-Key: invalid-product-01
Content-Type: application/json
Accept: application/json

{"name":"","category":"Beauty","price":799,"stock":3}
```

400 (malformed JSON):

```http
POST /products HTTP/1.1
Host: localhost:3000
Authorization: Bearer shoppilot-demo-token
Idempotency-Key: malformed-json-01
Content-Type: application/json
Accept: application/json

{"name":
```

400 means the request cannot be parsed as valid JSON; 422 means the JSON parses, but its values violate product rules.

### 5. Browser blocked despite server logging 200: who blocked it, and fix?

The browser enforces CORS and blocks JavaScript from exposing a cross-origin response when the server does not authorize that origin. Return a suitable `Access-Control-Allow-Origin` value and answer OPTIONS preflight with allowed methods and headers. This implementation uses `http://localhost:5173` as the default allowed origin, configurable with `ALLOWED_ORIGIN`.

### 6. Cache-Control allowing cache vs no-store

`GET /products` uses `Cache-Control: public, max-age=30` because catalog search results can be reused briefly. `POST /products` and successful writes use `Cache-Control: no-store` because mutation responses should not be stored by shared caches and may contain newly created or changing state. User-specific account/alert data should also use `private, no-store` where appropriate.

### 7. When should search use POST, and what is lost?

Use POST for complex structured search criteria that are too large or sensitive for a URL, or for a search operation that intentionally creates a saved search resource. Switching a pure search to POST loses normal GET caching, bookmarkability, simple sharing, and the safe-method expectation. This API uses GET with query parameters for ordinary filtering/sorting/pagination.

### 8. What does Location mean on 201 and 3xx?

On `201 Created`, `Location` identifies the newly created resource. On a 3xx redirect, `Location` identifies the URI the client should request next. This API uses Location for the 201 create response; it does not need a redirect for the product creation flow.

## Assignment 3 artifact relationship

The supplied Assignment 3 ZIP contains `integration.pdf`, `partner.wsdl`, and SOAP request/response/fault XML for MsgBridge SMS. Those are retained in the submission under `assignment3-reference/` as the upstream integration reference. The REST product service in this ZIP is the Assignment 5 deliverable and does not pretend the SOAP partner endpoint is the product CRUD API.

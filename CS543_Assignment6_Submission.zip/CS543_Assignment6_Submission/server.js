'use strict';
const http = require('node:http');
const { URL } = require('node:url');
const PORT = Number(process.env.PORT || 3000);
const RATE_LIMIT = Number(process.env.RATE_LIMIT || 100);
const WINDOW_MS = 60_000;
const orders = new Map();
const idempotency = new Map();
const budgets = new Map();
let nextId = 1001;

function xmlEscape(v) { return String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;'); }
function toXml(value, root='order') {
  if (value === null || value === undefined) return `<${root}/>`;
  if (typeof value !== 'object') return `<${root}>${xmlEscape(value)}</${root}>`;
  return `<${root}>${Object.entries(value).map(([k,v]) => Array.isArray(v) ? `<${k}>${v.map(x=>toXml(x,'item')).join('')}</${k}>` : toXml(v,k)).join('')}</${root}>`;
}
function send(res, status, data, headers={}) {
  const body = data === undefined || status === 204 || status === 304 ? '' : (headers['Content-Type'] && headers['Content-Type'].startsWith('application/xml') ? `<?xml version="1.0" encoding="UTF-8"?>${toXml(data, data && data.type ? 'problem' : 'order')}` : JSON.stringify(data));
  const h = {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers};
  if (status===204 || status===304) delete h['Content-Type'];
  if (body && h['Content-Type'].startsWith('application/xml')) h['Content-Type']='application/xml; charset=utf-8';
  res.writeHead(status,h); res.end(body);
}
const typeFor = {
  'empty-cart':'https://api.shoppilot.example/problems/empty-cart',
  'item-unavailable':'https://api.shoppilot.example/problems/item-unavailable',
  'payment-declined':'https://api.shoppilot.example/problems/payment-declined',
  'order-not-found':'https://api.shoppilot.example/problems/order-not-found',
  'illegal-transition':'https://api.shoppilot.example/problems/illegal-transition',
  'validation-error':'https://api.shoppilot.example/problems/validation-error',
  'rate-limit-exceeded':'https://api.shoppilot.example/problems/rate-limit-exceeded',
  'not-acceptable':'https://api.shoppilot.example/problems/not-acceptable',
  'internal-error':'https://api.shoppilot.example/problems/internal-error',
  'bad-request':'https://api.shoppilot.example/problems/bad-request',
  'unauthorized':'https://api.shoppilot.example/problems/unauthorized',
  'method-not-allowed':'https://api.shoppilot.example/problems/method-not-allowed',
  'not-found':'https://api.shoppilot.example/problems/not-found'
};
function problem(res,status,kind,title,detail,extra={},headers={}) {
  return send(res,status,{type:typeFor[kind]||`https://api.shoppilot.example/problems/${kind}`,title,status,detail,...extra},{'Content-Type':'application/problem+json; charset=utf-8',...headers});
}
function accepts(req,res) {
  const accept=(req.headers.accept||'*/*').toLowerCase();
  if (accept.includes('*/*') || accept.includes('application/json') || accept.includes('application/problem+json')) return 'json';
  if (accept.includes('application/xml') || accept.includes('text/xml')) return 'xml';
  problem(res,406,'not-acceptable','Not Acceptable','This service can produce application/json or application/xml.',{}, {'Vary':'Accept'});
  return null;
}
function sendFor(req,res,status,data,headers={}) {
  const format=accepts(req,res); if (!format) return;
  if (data && data.type && format==='json') headers['Content-Type']='application/problem+json; charset=utf-8';
  if (format==='xml') headers['Content-Type']='application/xml; charset=utf-8';
  return send(res,status,data,headers);
}
function readBody(req) {
  return new Promise((resolve,reject)=>{
    let raw='';
    req.on('data',chunk=>{raw+=chunk; if(raw.length>1_000_000){ const e=new Error('body too large');e.status=413;reject(e);req.destroy();}});
    req.on('end',()=>{if(!raw.trim())return resolve({});try{resolve(JSON.parse(raw));}catch(e){const x=new Error('Malformed JSON');x.status=400;reject(x);}});
    req.on('error',reject);
  });
}
function validateOrder(body) {
  const errors=[];
  if (!Array.isArray(body.items) || body.items.length===0) errors.push({field:'items',message:'must be a non-empty array'});
  else body.items.forEach((item,i)=>{
    if (!item || typeof item!=='object' || typeof item.productId!=='string' || !item.productId.trim()) errors.push({field:`items[${i}].productId`,message:'is required'});
    if (!item || !Number.isInteger(item.qty) || item.qty<1) errors.push({field:`items[${i}].qty`,message:'must be an integer greater than or equal to 1'});
    if (item && item.available===false) errors.push({field:`items[${i}].productId`,message:'item is unavailable'});
  });
  if (typeof body.address!=='string' || !body.address.trim()) errors.push({field:'address',message:'is required and must be a non-empty string'});
  if (body.paymentDeclined===true) errors.push({field:'payment',message:'payment was declined'});
  return errors;
}
function rateLimit(req,res) {
  const key=req.socket.remoteAddress||'unknown', now=Date.now();
  let b=budgets.get(key); if(!b||now>=b.resetAt)b={count:0,resetAt:now+WINDOW_MS};
  b.count++;budgets.set(key,b);
  if(b.count>RATE_LIMIT){const retry=Math.max(1,Math.ceil((b.resetAt-now)/1000));problem(res,429,'rate-limit-exceeded','Too Many Requests','Request rate limit exceeded; retry after the indicated delay.',{}, {'Retry-After':String(retry)});return false;}
  return true;
}
function publicOrder(o){const {paymentDeclined,version,...x}=o;return x;}
const server=http.createServer(async(req,res)=>{
  if (process.env.SERVICE_UNAVAILABLE === '1') return problem(res,503,'internal-error','Service Unavailable','The service is temporarily unavailable. Retry after the indicated delay.',{}, {'Retry-After':'30'});
  if(!rateLimit(req,res))return;
  const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
  const parts=url.pathname.split('/').filter(Boolean);
  try {
    if(req.method==='GET'&&url.pathname==='/health')return sendFor(req,res,200,{status:'ok',service:'ShopPilot AI Orders API'});
    if(parts[0]==='orders'&&parts.length===1&&req.method==='POST'){
      const key=req.headers['idempotency-key'];
      if(!key||!String(key).trim())return problem(res,400,'bad-request','Bad Request','Idempotency-Key header is required for POST /orders.');
      if(idempotency.has(key)){const old=idempotency.get(key);return sendFor(req,res,old.status,old.body,{'Location':old.location,'Idempotency-Replayed':'true'});}
      const body=await readBody(req), errors=validateOrder(body);
      if(errors.length){
        const empty=errors.some(e=>e.field==='items'&&e.message==='must be a non-empty array');
        const unavailable=errors.some(e=>e.message==='item is unavailable');
        const payment=errors.some(e=>e.field==='payment');
        const kind=empty?'empty-cart':unavailable?'item-unavailable':payment?'payment-declined':'validation-error';
        const status=payment?402:422;
        return problem(res,status,kind,payment?'Payment Required':empty?'Empty Cart':unavailable?'Item Unavailable':'Validation Failed',
          payment?'Payment could not be authorised.':empty?'At least one item is required to create an order.':unavailable?'One or more requested items are unavailable.':'One or more request fields are invalid.',{errors});
      }
      const id=String(nextId++), order={id,items:body.items.map(x=>({productId:x.productId,qty:x.qty})),address:body.address.trim(),status:'PENDING',createdAt:new Date().toISOString(),version:1};
      orders.set(id,order);const bodyOut=publicOrder(order),location=`/orders/${id}`;
      idempotency.set(key,{status:201,body:bodyOut,location});
      return sendFor(req,res,201,bodyOut,{Location:location,ETag:`"order-${id}-v1"`});
    }
    if(parts[0]==='orders'&&parts.length===2){
      const id=parts[1],order=orders.get(id);
      if(req.method==='GET'){
        if(!order)return problem(res,404,'order-not-found','Order Not Found',`Order ${id} does not exist.`);
        return sendFor(req,res,200,publicOrder(order),{ETag:`"order-${id}-v${order.version}"`});
      }
      if(req.method==='PATCH'){
        if(!order)return problem(res,404,'order-not-found','Order Not Found',`Order ${id} does not exist.`);
        const body=await readBody(req);
        if(!['CONFIRMED','CANCELLED'].includes(body.status))return problem(res,422,'validation-error','Validation Failed','status must be CONFIRMED or CANCELLED.',{errors:[{field:'status',message:'must be CONFIRMED or CANCELLED'}]});
        const allowed=(order.status==='PENDING'&&['CONFIRMED','CANCELLED'].includes(body.status))||(order.status==='CONFIRMED'&&body.status==='CANCELLED');
        if(!allowed)return problem(res,409,'illegal-transition','Illegal Order Status Transition',`Cannot change order status from ${order.status} to ${body.status}.`);
        order.status=body.status;order.version++;
        return sendFor(req,res,200,publicOrder(order),{ETag:`"order-${id}-v${order.version}"`});
      }
      if(req.method==='DELETE'){
        if(!order)return problem(res,404,'order-not-found','Order Not Found',`Order ${id} does not exist.`);
        if(order.status!=='PENDING')return problem(res,409,'illegal-transition','Illegal Order Status Transition','Only a PENDING order can be deleted.');
        orders.delete(id);return sendFor(req,res,204,undefined);
      }
    }
    if(parts[0]==='orders')return problem(res,405,'method-not-allowed','Method Not Allowed','Method is not allowed for this orders resource.',{}, {'Allow':'GET, POST, PATCH, DELETE, OPTIONS'});
    return problem(res,404,'not-found','Not Found','Route was not found.');
  } catch(err) {
    // Details stay in server logs; never send exception/database internals to clients.
    console.error('[orders-service] internal failure:',err && err.stack ? err.stack : err);
    if(!res.headersSent)return problem(res,err.status||500,err.status===400?'bad-request':'internal-error',err.status===400?'Bad Request':'Internal Server Error',err.status===400?'Request body must contain valid JSON.':'The server could not complete the request safely.');
  }
});
server.requestTimeout=10_000;
server.headersTimeout=12_000;
server.listen(PORT,()=>console.log(`ShopPilot AI Orders API listening on http://localhost:${PORT}`));
module.exports={server,orders,idempotency,validateOrder};

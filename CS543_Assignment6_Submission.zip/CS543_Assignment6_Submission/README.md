# ShopPilot AI — CS543 Assignment 6

This is the Assignment 6 update to the service entry point (`server.js`) in the provided Assignment 5 archive. The uploaded A5 package implements a Product API rather than an Orders API; Assignment 6 explicitly specifies `/orders`, so this version implements the required Orders contract while carrying forward the A5 idempotency-key replay pattern and bounded HTTP request timeouts. It does not claim to preserve product routes.

## Run

Requires Node.js 18+ and curl.

```sh
npm start
# another terminal
npm test
```

Default URL: `http://localhost:3000`. Set `PORT` and `RATE_LIMIT` as needed. `POST /orders` requires an `Idempotency-Key`.

## Example request

```sh
curl -i -X POST http://localhost:3000/orders \
  -H 'Content-Type: application/json' -H 'Accept: application/json' \
  -H 'Idempotency-Key: order-demo-1' \
  -d '{"items":[{"productId":"SKU-101","qty":2}],"address":"Gandhinagar, Gujarat"}'
```

`transcript.txt` is the curl verification transcript. Re-run commands if you need fresh IDs/timestamps. In-memory orders and idempotency records reset when the process restarts; production use would require durable storage.

'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const http=require('node:http');
let child,base;
function req(method,path,headers={},bodyRaw){
 return new Promise((resolve,reject)=>{
  const r=http.request(base+path,{method,headers:{Accept:'application/json',...headers}},res=>{
   let raw='';res.on('data',x=>raw+=x);res.on('end',()=>{let body;try{body=raw?JSON.parse(raw):undefined}catch{}resolve({status:res.statusCode,headers:res.headers,raw,body})});
  });r.on('error',reject);if(bodyRaw!==undefined)r.write(bodyRaw);r.end();
 });
}
function post(body,key){return req('POST','/orders',{'Content-Type':'application/json','Idempotency-Key':key},JSON.stringify(body))}
test.before(async()=>{
 const net=require('node:net');const srv=net.createServer();await new Promise(r=>srv.listen(0,'127.0.0.1',r));const port=srv.address().port;await new Promise(r=>srv.close(r));base=`http://127.0.0.1:${port}`;
 child=spawn(process.execPath,['server.js'],{cwd:require('node:path').join(__dirname,'..'),env:{...process.env,PORT:String(port),RATE_LIMIT:'1000'},stdio:'ignore'});
 for(let i=0;i<80;i++){try{const x=await req('GET','/health');if(x.status===200)return;}catch{}await new Promise(r=>setTimeout(r,40));}
 throw new Error('server did not start');
});
test.after(()=>{if(child)child.kill()});
test('POST returns 201, Location, and same idempotency key replays original',async()=>{
 const b={items:[{productId:'SKU-101',qty:2}],address:'Gandhinagar'};
 const a=await post(b,'idempotency-test-1'),again=await post(b,'idempotency-test-1');
 assert.equal(a.status,201);assert.match(a.headers.location,/^\/orders\/\d+$/);assert.equal(again.status,201);assert.equal(a.body.id,again.body.id);assert.equal(again.headers['idempotency-replayed'],'true');
});
test('empty cart and multiple field errors return Problem Details 422',async()=>{
 const a=await post({items:[],address:'X'},'empty-cart-1');assert.equal(a.status,422);assert.match(a.headers['content-type'],/application\/problem\+json/);assert.match(a.body.type,/empty-cart/);
 const b=await post({items:[{productId:'SKU',qty:0}],address:''},'bad-fields-1');assert.equal(b.status,422);assert.equal(b.body.errors.length,2);
});
test('GET unknown ID gives 404 Problem Details',async()=>{const r=await req('GET','/orders/unknown-id');assert.equal(r.status,404);assert.match(r.body.type,/order-not-found/);});
test('PATCH transitions pending to confirmed then rejects illegal transition',async()=>{
 const c=await post({items:[{productId:'SKU-102',qty:1}],address:'Test Road'},'transition-test-1');const id=c.body.id;
 const a=await req('PATCH',`/orders/${id}`,{'Content-Type':'application/json'},JSON.stringify({status:'CONFIRMED'}));assert.equal(a.status,200);
 const b=await req('PATCH',`/orders/${id}`,{'Content-Type':'application/json'},JSON.stringify({status:'PENDING'}));assert.equal(b.status,422); // invalid target status
 const del=await req('DELETE',`/orders/${id}`);assert.equal(del.status,409);assert.match(del.body.type,/illegal-transition/);
});
test('Accept XML returns XML; unsupported Accept returns 406',async()=>{
 const c=await post({items:[{productId:'SKU-103',qty:1}],address:'Test Road'},'xml-test-1');
 const xml=await req('GET',`/orders/${c.body.id}`,{Accept:'application/xml'});assert.equal(xml.status,200);assert.match(xml.headers['content-type'],/application\/xml/);assert.match(xml.raw,/<order>/);
 const bad=await req('GET',`/orders/${c.body.id}`,{Accept:'image/png'});assert.equal(bad.status,406);assert.match(bad.body.type,/not-acceptable/);
});
test('malformed JSON is clean 400 Problem Details',async()=>{
 const r=await req('POST','/orders',{'Content-Type':'application/json','Idempotency-Key':'bad-json-1'},'{bad');
 assert.equal(r.status,400);assert.match(r.headers['content-type'],/application\/problem\+json/);assert.doesNotMatch(r.raw,/SyntaxError|stack/i);
});

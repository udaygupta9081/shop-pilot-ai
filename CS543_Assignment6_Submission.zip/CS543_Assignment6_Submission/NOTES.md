# CS543 Web Services — Assignment 6: Honest Responses

**Project:** ShopPilot AI Orders API  
**Team ID:** [FILL IN TEAM ID]  
**Team members (Roll No — Full Name):**
- [Add every team member's roll number and full name]

## Implementation note

The uploaded Assignment 5 archive contains a ShopPilot AI **Product API** (`POST/GET/PUT/PATCH/DELETE /products`), while Assignment 6 explicitly asks for the **same Orders service** and defines `/orders`. The supplied repository does not contain the prior Orders service. To follow the Assignment 6 contract without claiming the Product API was an Orders API, this submission uses the existing service entry-point pattern and implements the specified Orders resource. The A5 idempotency-key replay pattern and HTTP request timeout limits are retained. This repository discrepancy should be checked with the instructor if they expect a specific A5 Orders implementation.

## 1. Status map: endpoints, success status and failures

| Endpoint | Success | Failure statuses and reason |
|---|---|---|
| `GET /health` | `200 OK` — health representation returned | `406 Not Acceptable` if the client requests an unsupported representation; `429 Too Many Requests` when the client exceeds the rate budget; `503 Service Unavailable` during configured maintenance, with `Retry-After` |
| `POST /orders` | `201 Created` plus `Location: /orders/{id}` — the new order has a stable URI | `400 Bad Request` for missing Idempotency-Key or malformed JSON; `402 Payment Required` for declined payment; `406` for unsupported `Accept`; `422 Unprocessable Content` for empty cart or invalid fields; `429` for rate limit; `503` for temporary service unavailability. Every error uses Problem Details |
| `GET /orders/{id}` | `200 OK` — order representation and ETag returned | `404 Not Found` when the ID does not exist; `406` for unsupported `Accept`; `429` for rate limit; `503` for temporary unavailability |
| `PATCH /orders/{id}` | `200 OK` — status updated | `404` for unknown ID; `409 Conflict` for illegal state transition; `422` for invalid/missing status; `400` for malformed JSON; `406`, `429`, or `503` as applicable |
| `DELETE /orders/{id}` | `204 No Content` — pending order deleted, no body | `404` for unknown ID; `409 Conflict` when an order is not PENDING and cannot be deleted; `406`, `429`, or `503` as applicable |
| Unsupported `/orders` method | none | `405 Method Not Allowed` with `Allow` header |
| Unknown route | none | `404 Not Found` with Problem Details |

The service always sets `Content-Type` with UTF-8 for response bodies. JSON errors use `application/problem+json; charset=utf-8`; successful JSON uses `application/json; charset=utf-8`; successful XML uses `application/xml; charset=utf-8`. A `204` response has no body and no Content-Type.

## 2. Stable Problem Details type catalogue

The service uses stable URI type identifiers, not exception messages:

| Type suffix | Trigger | Status |
|---|---|---:|
| `empty-cart` | `items` is missing, not an array, or empty | 422 |
| `item-unavailable` | an item has `available: false` | 422 |
| `payment-declined` | demo request includes `paymentDeclined: true` | 402 |
| `order-not-found` | GET/PATCH/DELETE uses an unknown order ID | 404 |
| `illegal-transition` | requested state change is not allowed, or delete is attempted on a non-pending order | 409 |
| `validation-error` | invalid item fields, quantity, address, or status | 422 |
| `rate-limit-exceeded` | per-process request count exceeds RATE_LIMIT in a minute | 429 |
| `not-acceptable` | client requests an unsupported response format | 406 |
| `bad-request` | missing Idempotency-Key or malformed JSON | 400 |
| `internal-error` | unexpected internal failure or maintenance-mode response | 500 or 503 |

## 3. Example Problem Details body and fields

```json
{
  "type": "https://api.shoppilot.example/problems/validation-error",
  "title": "Validation Failed",
  "status": 422,
  "detail": "One or more request fields are invalid.",
  "errors": [
    {"field": "items[0].qty", "message": "must be an integer greater than or equal to 1"},
    {"field": "address", "message": "is required and must be a non-empty string"}
  ]
}
```

- `type`: stable URI identifying the class of problem.
- `title`: short human-readable summary.
- `status`: HTTP status code for this occurrence.
- `detail`: safe explanation of this occurrence; it does not expose internal exception messages.
- `errors`: optional extension listing every invalid field and the reason.

The actual response header is `Content-Type: application/problem+json; charset=utf-8`.

## 4. Field-level 422 reporting two errors at once

Request:

```json
{"items":[{"productId":"SKU-101","qty":0}],"address":""}
```

The response is `422 Unprocessable Content` with both `items[0].qty` (`must be an integer greater than or equal to 1`) and `address` (`is required and must be a non-empty string`) in `errors[]`. Validation runs across all fields before creating an order, so the caller can fix the whole request in one pass.

## 5. Retry safety and status codes

- `GET /orders/{id}` and `GET /health` are safe and idempotent; they can be retried after transient network failures.
- `POST /orders` is not inherently idempotent. It requires `Idempotency-Key`; repeating the same key replays the original `201` response and `Location` rather than creating a duplicate order. This follows the A5 archive's idempotency-key replay pattern.
- `PATCH /orders/{id}` changes state and should not be blindly retried after an ambiguous timeout. Fetch the order with GET first; the state machine rejects illegal transitions with `409`.
- `DELETE /orders/{id}` should not be blindly retried after a timeout because the first attempt may already have deleted it; a later attempt returns `404`.
- `429 Too Many Requests` and `503 Service Unavailable` include `Retry-After`. Clients should wait at least that number of seconds before retrying a transient request. A 4xx response must not be retried unchanged; correct the request or state first.
- The A5 code used an in-memory idempotency map. That demonstrates the behavior but is not durable across restarts; production should store keys and results in persistent storage.

## 6. Internal errors and information hidden

Risky request-body parsing and request processing are wrapped in `try/catch`. The catch block logs the exception and stack trace server-side with `console.error`, then returns a mapped `500` Problem Details response with the generic detail “The server could not complete the request safely.” The caller does not receive the stack trace, internal exception text, database details, or filesystem paths. Malformed JSON is mapped to a clean `400` response. A maintenance-mode `503` is also generic and includes `Retry-After: 30`.

## 7. Same order as JSON and XML

Create the order with `Accept: application/json` to receive JSON, then request the returned order URI with `Accept: application/xml` to receive an XML representation. The XML negotiation uses the same order resource; only the representation format changes. If a client sends an unsupported header such as `Accept: image/png`, the service returns `406 Not Acceptable`.

## A5 idempotency and timeout regression checks

The create path still requires an `Idempotency-Key` and stores the first successful `201` response for replay. The server's Node HTTP `requestTimeout` is 10 seconds and `headersTimeout` is 12 seconds. `npm test` covers replay, success Location, validation, unknown IDs, legal/illegal transitions, XML negotiation and unsupported Accept. These timeout settings bound request processing; they do not implement a durable distributed timeout or persistent idempotency store.

## Submission checklist

- [x] Updated service source (`server.js`)
- [x] Updated OpenAPI description (`openapi.yaml`)
- [x] curl transcript (`transcript.txt`)
- [x] Notes answering all seven questions (`NOTES.md`)
- [ ] Replace Team ID placeholder and add every team member's roll number/name
